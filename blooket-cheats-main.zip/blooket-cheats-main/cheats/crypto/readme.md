# Crypto Hack Cheats

## [Always Triple](alwaysTriple.js)
Always get triple crypto

## [Auto Guess](autoGuess.js)
Automatically guess the correct password

## [Choice ESP](choiceESP.js)
Shows what each choice will give you

## [Password ESP](passwordESP.js)
Highlights the correct password

## [Remove Hack](removeHack.js)
Removes an attacking hack

## [Set Crypto](setCrypto.js)
Sets crypto

## [Set Password](setPassword.js)
Sets hacking password

## [Steal Player's Crypto](stealPlayersCrypto.js)
Steals all of someone's crypto