# Tower Defense 2 Cheats

## [Max Towers](maxTowers.js)
Makes all your towers op

## [Kill Enemies](removeEnemies.js)
Removes all the enemies

## [Set Coins](setCoins.js)
Sets amount of coins you have

## [Set Health](setDmg.js)
Sets amount of health you have

## [Set Round](setRound.js)
Sets the current round